from .tct_tsconfig import *

__doc__ = tct_tsconfig.__doc__
if hasattr(tct_tsconfig, "__all__"):
    __all__ = tct_tsconfig.__all__