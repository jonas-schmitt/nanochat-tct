from .tct_eslintrc_bpe_500 import *

__doc__ = tct_eslintrc_bpe_500.__doc__
if hasattr(tct_eslintrc_bpe_500, "__all__"):
    __all__ = tct_eslintrc_bpe_500.__all__