from .tct_tsconfig_base import *

__doc__ = tct_tsconfig_base.__doc__
if hasattr(tct_tsconfig_base, "__all__"):
    __all__ = tct_tsconfig_base.__all__